import os, re, sys, shutil, json, subprocess, datetime, zoneinfo, random, requests
from PIL import Image, ImageDraw, ImageFont
import arabic_reshaper
from bidi.algorithm import get_display

LONG = os.environ.get("VIDEO_FORMAT") == "long"
W, H = (1920, 1080) if LONG else (1080, 1920)   # الطويل أفقي، الشورت عمودي
TZ = zoneinfo.ZoneInfo("Asia/Baghdad")
ROOT = os.path.dirname(os.path.abspath(__file__))
SCHEDULE = os.path.join(ROOT, "schedule.json")
WORK = os.path.join(ROOT, "work")
os.makedirs(WORK, exist_ok=True)

RECITERS = {
    "Alafasy_128kbps": "مشاري العفاسي",
    "Abdul_Basit_Murattal_192kbps": "عبد الباسط عبد الصمد",
    "Husary_128kbps": "محمود خليل الحصري",
    "Minshawy_Murattal_128kbps": "محمد صديق المنشاوي",
    "Abdurrahmaan_As-Sudais_192kbps": "عبد الرحمن السديس",
    "Yasser_Ad-Dussary_128kbps": "ياسر الدوسري",
}

def find_font():
    for name in ["Amiri", "Noto Naskh Arabic"]:
        p = subprocess.run(["fc-match", "-f", "%{file}", name], capture_output=True, text=True).stdout
        if p:
            return p
FONT = find_font()

def shape(s):
    return get_display(arabic_reshaper.reshape(s))

def wrap(draw, font, text, maxw):
    lines, cur = [], ""
    for w in text.split():
        t = (cur + " " + w).strip()
        if draw.textlength(shape(t), font=font) <= maxw:
            cur = t
        else:
            lines.append(cur); cur = w
    if cur:
        lines.append(cur)
    return lines

def background():
    img = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(img)
    for y in range(H):
        k = y / H
        d.line([(0, y), (W, y)], fill=(int(8 + 10 * k), int(40 - 14 * k), int(30 - 6 * k)))
    return img

def render(text, footer, path):
    img = background()
    d = ImageDraw.Draw(img)
    size = 88
    while size > 34:
        font = ImageFont.truetype(FONT, size)
        lines = wrap(d, font, text, W - 160)
        lh = int(size * 1.9)
        if len(lines) * lh <= int(H * 0.65):
            break
        size -= 4
    y = (H - len(lines) * lh) // 2 - 40
    for ln in lines:
        d.text((W / 2, y), shape(ln), font=font, fill=(245, 240, 220), anchor="ma")
        y += lh
    f2 = ImageFont.truetype(FONT, 50)
    d.text((W / 2, H - int(H * 0.135)), shape(footer), font=f2, fill=(212, 175, 90), anchor="ma")
    img.save(path)

def duration(p):
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                          "-of", "csv=p=0", p], capture_output=True, text=True).stdout
    return float(out.strip())

def silence_bounds(path, nseg):
    # يقسم الصوت إلى nseg مقطع عند أطول (nseg-1) فترات سكوت
    r = subprocess.run(["ffmpeg", "-i", path, "-af", "silencedetect=noise=-35dB:d=0.3", "-f", "null", "-"],
                       capture_output=True, text=True)
    starts = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", r.stderr)]
    ends = re.findall(r"silence_end: ([\d.]+) \| silence_duration: ([\d.]+)", r.stderr)
    total = duration(path)
    sil = []
    for st, (en, du) in zip(starts, ends):
        mid = (st + float(en)) / 2
        if st > 0.3 and mid < total - 0.5:
            sil.append((float(du), mid))
    if len(sil) < nseg - 1:
        raise SystemExit(f"لقيت {len(sil)} وقفة فقط والمطلوب {nseg - 1}. حدد التوقيتات يدوياً بحقل timings أو جرّب skip_start")
    cuts = sorted(m for _, m in sorted(sil, reverse=True)[:nseg - 1])
    b = [0.0] + cuts + [total]
    return [(b[i], b[i + 1]) for i in range(nseg)]

def build(entry):
    s, a, b = entry["surah"], entry["from"], entry["to"]
    reciter = entry.get("reciter", "Alafasy_128kbps")
    label = entry.get("reciter_name") or RECITERS.get(reciter, reciter)
    clips, surah_name = [], ""
    segs, off, manual, full = None, 0, False, None
    if entry.get("audio_url"):
        full = os.path.join(WORK, "full.mp3")
        r = requests.get(entry["audio_url"], timeout=300); r.raise_for_status()
        open(full, "wb").write(r.content)
        if entry.get("skip_start"):
            cut = os.path.join(WORK, "trim.mp3")
            subprocess.run(["ffmpeg", "-y", "-ss", str(entry["skip_start"]), "-i", full, "-c:a", "libmp3lame", "-q:a", "2", cut],
                           check=True, capture_output=True)
            full = cut
        if entry.get("timings"):
            manual = True
            segs = [tuple(float(x) for x in t.split("-")) for t in entry["timings"]]
        else:
            n_ay = requests.get(f"https://api.alquran.cloud/v1/surah/{s}", timeout=30).json()["data"]["numberOfAyahs"]
            off = 0 if s in (1, 9) else 1  # أول مقطع = البسملة (يُهمل)
            segs = silence_bounds(full, n_ay + off)
    for n in range(a, b + 1):
        j = requests.get(f"https://api.alquran.cloud/v1/ayah/{s}:{n}/quran-uthmani", timeout=30).json()["data"]
        surah_name = j["surah"]["name"]
        text = j["text"]
        # الـ API يضيف البسملة قبل أول آية، والصوت ما يحتويها (إلا الفاتحة)
        if j["numberInSurah"] == 1 and s not in (1, 9):
            text = " ".join(text.split()[4:])
        mp3 = os.path.join(WORK, f"{n}.mp3")
        if segs:
            st, en = segs[n - a] if manual else segs[n - 1 + off]
            subprocess.run(["ffmpeg", "-y", "-i", full, "-ss", f"{st:.2f}", "-to", f"{en:.2f}",
                            "-c:a", "libmp3lame", "-q:a", "2", mp3], check=True, capture_output=True)
        else:
            url = f"https://everyayah.com/data/{reciter}/{s:03d}{n:03d}.mp3"
            r = requests.get(url, timeout=60)
            if r.status_code == 404:
                raise SystemExit(f"القارئ غير موجود على EveryAyah: {reciter} (شغّل find_reciter.py للبحث عن الاسم الصحيح)")
            r.raise_for_status()
            open(mp3, "wb").write(r.content)
        png = os.path.join(WORK, f"{n}.png")
        render(text + f" ﴿{n}﴾", f"{surah_name}  •  {label}", png)
        clip = os.path.join(WORK, f"{n}.mp4")
        subprocess.run(["ffmpeg", "-y", "-loop", "1", "-i", png, "-i", mp3, "-c:v", "libx264",
                        "-tune", "stillimage", "-r", "25", "-c:a", "aac", "-b:a", "192k",
                        "-pix_fmt", "yuv420p", "-shortest", clip], check=True, capture_output=True)
        clips.append(clip)
    lst = os.path.join(WORK, "list.txt")
    open(lst, "w").write("".join(f"file '{c}'\n" for c in clips))
    out = os.path.join(WORK, "final.mp4")
    subprocess.run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", out],
                   check=True, capture_output=True)
    return out, surah_name, label

def pick_time(entry, today):
    # وقت النشر: إما وقت محدد من الموقع، أو عشوائي ضمن الفترة PUBLISH_FROM إلى PUBLISH_TO بتوقيت بغداد
    d = datetime.date.fromisoformat(today)
    if entry.get("time"):
        h, m = map(int, entry["time"].split(":"))
    else:
        a = os.environ.get("PUBLISH_FROM", "10:00").split(":")
        b = os.environ.get("PUBLISH_TO", "23:00").split(":")
        lo, hi = int(a[0]) * 60 + int(a[1]), int(b[0]) * 60 + int(b[1])
        if hi <= lo:
            hi += 24 * 60  # الفترة تعدّي منتصف الليل
        h, m = divmod(random.randint(lo, hi), 60)
    dt = datetime.datetime(d.year, d.month, d.day, tzinfo=TZ) + datetime.timedelta(hours=h, minutes=m)
    soon = datetime.datetime.now(TZ) + datetime.timedelta(minutes=30)
    if dt < soon:
        dt = soon
    return dt.astimezone(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")

def upload(path, title, desc, publish_at):
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build as gbuild
    from googleapiclient.http import MediaFileUpload
    creds = Credentials(None, refresh_token=os.environ["YT_REFRESH_TOKEN"],
                        token_uri="https://oauth2.googleapis.com/token",
                        client_id=os.environ["YT_CLIENT_ID"],
                        client_secret=os.environ["YT_CLIENT_SECRET"])
    yt = gbuild("youtube", "v3", credentials=creds)
    body = {"snippet": {"title": title[:100], "description": desc, "categoryId": "22",
                        "tags": ["قرآن", "تلاوة", "Quran", "Shorts"]},
            "status": {"selfDeclaredMadeForKids": False}}
    privacy = os.environ.get("PRIVACY", "scheduled")
    if privacy == "scheduled":
        body["status"].update(privacyStatus="private", publishAt=publish_at)
    else:
        body["status"]["privacyStatus"] = privacy
    req = yt.videos().insert(part="snippet,status", body=body,
                             media_body=MediaFileUpload(path, chunksize=-1, resumable=True))
    resp = None
    while resp is None:
        _, resp = req.next_chunk()
    return resp["id"]

STATE = os.path.join(ROOT, "auto_state.json")
AUTO_RECITERS = ["Alafasy_128kbps", "Abdul_Basit_Murattal_192kbps", "Husary_128kbps",
                 "Minshawy_Murattal_128kbps", "Abdurrahmaan_As-Sudais_192kbps", "Yasser_Ad-Dussary_128kbps"]

def auto_entry(today):
    """يختار آيات اليوم تلقائياً: تسلسلي (يكمل من وين وقف) أو عشوائي."""
    counts = {x["number"]: x["numberOfAyahs"]
              for x in requests.get("https://api.alquran.cloud/v1/surah", timeout=30).json()["data"]}
    k = int(os.environ.get("AUTO_AYAHS", "5"))
    mode = os.environ.get("AUTO_MODE", "sequential")
    if mode == "random":
        sur = random.randint(1, 114)
        a = random.randint(1, counts[sur])
    else:
        st = json.load(open(STATE)) if os.path.exists(STATE) else {"surah": 1, "ayah": 1}
        sur, a = st["surah"], st["ayah"]
    b = min(a + k - 1, counts[sur])
    if mode != "random":
        nxt = {"surah": sur % 114 + 1, "ayah": 1} if b == counts[sur] else {"surah": sur, "ayah": b + 1}
        json.dump(nxt, open(STATE, "w"))
    reciters = [r for r in os.environ.get("AUTO_RECITERS", "").split(",") if r] or AUTO_RECITERS
    return {"date": today, "surah": sur, "from": a, "to": b, "reciter": random.choice(reciters), "title": "", "auto": True}

def clean(t):
    t = re.sub(r"[\u064B-\u065F\u0670\u06D6-\u06ED\u0640]", "", t)
    return t.replace("\u0671", "ا")

def hashtags(name, label):
    base = os.environ.get("HASHTAGS", "#قرآن #القرآن_الكريم #تلاوة #Quran #Shorts").split()
    sname = clean(name).replace("سورة", "").strip().replace(" ", "_")
    extra = [f"#سورة_{sname}", "#" + clean(label).replace(" ", "_")]
    out = []
    for h in base + extra:
        if h not in out:
            out.append(h)
    return " ".join(out[:15])   # يوتيوب يتجاهل أكثر من 15

def main():
    today = os.environ.get("RUN_DATE") or datetime.datetime.now(TZ).date().isoformat()
    items = json.load(open(SCHEDULE, encoding="utf-8"))
    todays = [e for e in items if e["date"] == today]
    if any(e.get("video_id") for e in todays):
        print("فيديو اليوم انرفع من قبل:", today); return
    entry = todays[0] if todays else None   # لو حددت يوم معين من الموقع يأخذه، وإلا تلقائي
    if not entry:
        entry = auto_entry(today)
        items.append(entry)
    out, name, label = build(entry)
    title = entry.get("title") or f"{name} ({entry['from']}-{entry['to']}) | {label} #Shorts"
    desc = f"{name} - الآيات {entry['from']} إلى {entry['to']}\nالقارئ: {label}\n\n{hashtags(name, label)}"
    publish_at = pick_time(entry, today)
    entry["video_id"] = upload(out, title, desc, publish_at)
    entry["publish_at"] = publish_at
    json.dump(items, open(SCHEDULE, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    print("تم الرفع:", entry["video_id"])

def main_long():
    """فيديو طويل أفقي بدون رفع: يحفظه بمجلد output لتنزله يدوياً."""
    e = {"surah": int(os.environ["SURAH"]), "from": int(os.environ["FROM_AYAH"]),
         "to": int(os.environ["TO_AYAH"]), "reciter": os.environ.get("RECITER") or "Alafasy_128kbps"}
    if os.environ.get("RECITER_NAME"):
        e["reciter_name"] = os.environ["RECITER_NAME"]
    if os.environ.get("AUDIO_URL"):
        e["audio_url"] = os.environ["AUDIO_URL"]
    out, name, label = build(e)
    os.makedirs(os.path.join(ROOT, "output"), exist_ok=True)
    dest = os.path.join(ROOT, "output", f"quran_{e['surah']}_{e['from']}-{e['to']}.mp4")
    shutil.copy(out, dest)
    print("جاهز:", dest, "| العنوان المقترح:", f"{name} ({e['from']}-{e['to']}) | {label}")

if __name__ == "__main__":
    main_long() if len(sys.argv) > 1 and sys.argv[1] == "long" else main()
